﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAM5430.Class05
{
    public class Account
    {
        private string _name;
        public bool Is_Active; //field*/
        public bool IsActive
        {
            get; private set;
        }

        public Account(string name)//constructor has to match the class name
        {
            //if(name!=null && name!= "")
            //{
            Name = name;
            //}
            //Is_active = true;
            //IsActive = true;

        }
        public Account(string name, bool isActive)//using line 16 from Program
        {
            Name = name;//this is saving that name into _name by way of line 58 set function because you are setting Name "=" to name
            IsActive = Is_Active = isActive;
        }

        public override string ToString()

        {
            if (IsActive)
            {
                return ($"Active Account {Name}");
            }
            else
            {
                return $"Inactive Account {Name}";
            }
        }
    
    
        public string GetName()
        {
            return _name;
        }

        public void SetName(string name)
        {
            _name = name;
        }

        public string Name//this is the same as lines 23
        {
            get
            {
                return _name;
            }

            set
            {
                if (value!=null && value != "")
                {
                    _name = value;
                }
                
            }
        }
    }
}
