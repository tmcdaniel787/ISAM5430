﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISAM5430.Class05 
{
    class Program
    {
        static void Main(string[] args)
        {
            //constructor
            //the default constructor that is parameterless
            Account account = new Account("Terry", false);
            // a constructor forces you to initialize the required states. so you have to have something in the () since you created the constructor on lines 13-15 on Account.cs
            account.SetName("Terry");
            WriteLine("The name is " + account.GetName());
            account.Name = "McDaniel"; //this is the same function as line 
            //account.IsActive = true;
            //account.Is_Active = true;
            WriteLine("Is the account active? " + account.IsActive);
            WriteLine("The name 2 is " + account.Name);//this is the same function as 
            WriteLine(account.ToString());
            WriteLine(account);
            WriteLine(account.Name);
        }
    }
}
