﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2.PropertyMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            Account/*this refers to 'Account' on line nine of the class I created*/ myAccount /*this is a variable like 'a'*/= new Account();//this is just the standard function for a new class.
            Console.WriteLine($"Initial name is: {myAccount.Name}");//this is the program going to get the name. Initially there is nothing to get because we have not created it yet.

            Console.Write("Enter the name: ");//prompt user for name
            string theName = Console.ReadLine();//sets the variable for when the user inputs the name
            myAccount.Name=theName;//this sets the varable value of theName into myAcccount
            Console.WriteLine($"myAccount's name is: {myAccount.Name}");//this is showing the name that was just set in the SetName step.
        }
    }
}
