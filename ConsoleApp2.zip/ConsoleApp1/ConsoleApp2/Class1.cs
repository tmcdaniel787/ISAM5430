﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Account
    {
        private string _fname;//sets variable

        public string Name //this is the property value of 'Name'
        {
            get
            {
                return _fname; //this is the method to return the name when called
            }
            set //going to assign a new variable to the corresponding instance
            {
                _fname = value; //this is setting whatever the user inputs from the program to the value of name
            }
        }
        

    }
}
