﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Account account1 = new Account("Jane Green"); //this means we are going to set the Name to Jane Green when I request to return account1
            Account account2 = new Account("John Blue");//this means we are going to set the Name to Jane Green when I request to return account2

            Console.WriteLine($"account1 name is: {account1.Name}");
            Console.WriteLine($"account2 name is: {account2.Name}");

        }
    }
}
