﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Account
    {
        public string Name { get; set; } //this is the auto version property

        public Account(string accountName) //constructor with variable of accountName which is the input from the customer
        {
            Name = accountName;//this is where we are setting the user input value to the varable Name.
        }
    }
}
