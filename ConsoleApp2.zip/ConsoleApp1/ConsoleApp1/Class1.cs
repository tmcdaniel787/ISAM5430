﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Account
    {
        private string _fname;//this a variable 'name' set so there is a place to store the value from the program when the user inputs name. it is currently null
        
        public void SetName(string fName)//this setting a variable for theName to sit when it is input by the user.
        {
            _fname = fName;//takes what was stored in line 12 and sets it to the value of line 11.
            
        }
        public string GetName()
        {
            return _fname;//this is the method that allows the GetName call on the program to have a reference. since we set the name=accountName which came from the user input, it now will return a value when called
            
        }


    }
}
